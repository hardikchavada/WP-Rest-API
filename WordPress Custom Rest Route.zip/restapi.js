let restbtn = document.getElementById("rest-btn");
let mydiv = document.getElementById("rest-div");


const fetchapi = ()=>{

    //let url = "https://appsbizzhost.com.au/quality2/wp-json/wp/v2/posts";
    let catInput = document.getElementById("category_input").value;
    let url = `https://appsbizzhost.com.au/quality2/wp-json/custom-rest-route/v1/services/${catInput}`;
    
    let mydiv = document.getElementById("rest-div");
    let divdata = '';
            fetch(url)
            .then(function (response) {
                return response.json();
            }).
            then(function(data) {
                console.log(data);
                divdata = `<ul class="services-suburb list-style">`;
                for(i=0; i < data.length; i++){
                    
                    divdata += `<li class="services-suburb-inner"><a href="${data[i].permalink}">` ;
                    divdata += `${data[i].title}`;
                    divdata += `</a></li>`;
                }
                divdata += `</ul>`;
                mydiv.innerHTML = divdata;
                
            });
}