<?php 

add_action( 'rest_api_init', 'custom_services_rest_route');

function custom_services_rest_route () {
    register_rest_route( 'custom-rest-route/v1', 'services/(?P<slug>[a-z0-9]+(?:-[a-z0-9]+)*)', array( 
        'methods' => 'GET',
        'callback' => 'custom_rest_route_callback',
        'args'  => array(
            'slug' => array (
                'required' => true
            )
        )
    ));
}


//Calling a callback function. Line number 8

function custom_rest_route_callback(WP_REST_Request $request) {
   
    $slug = $request['slug']; 

    $args1 = array(
        'post_type' => 'service',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'service_cat',
                'field' => 'slug',
                'terms' => $slug
            )
        )
        
    );
    $get_posts = new WP_Query($args1);
    // echo "<pre>";
    // print_r($get_posts);
    // echo "</pre>";
    

    if($get_posts-> have_posts( )){           
        $postresult = array();
        while($get_posts-> have_posts( )) {
            $get_posts-> the_post( );  
            array_push($postresult, array (
                'title' => get_the_title( ),
                'permalink' => get_the_permalink( )
            ));
        }
        return $postresult;
    }
    else {
        return "no posts";
    }

    
}


?>