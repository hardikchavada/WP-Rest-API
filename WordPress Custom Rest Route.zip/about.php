<?php 
/**
 * The home template file
 *
 * This is the most generic template file in a WordPress theme and one
 * of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query,
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Template Name: About Us
 *
 */
 ?>
 <?php get_header(); ?>
 <?php  $theme_header = get_field('header_options','option'); ?>
 <!-- End Main Header -->
    <section class="about-us-section padding" style="padding-top:20px!important;">
        <div class="auto-container">

            <!-- about-area -->
            <section class="inner-about-area about-md-p pt-60 pb-120">
                <div class="container-fluid container-p container-about-p">
                    <div class="row align-items-end justify-content-center">
                        <div class="col-xl-5 col-lg-6">
                            <div class="s-choose-img p-relative">
                            <img src="<?php echo get_site_url();?>/wp-content/uploads/2021/04/Screenshot123.png" alt="about-1" class="img-fluid tilt-effect">
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 inner-about-padding">
                            <div class="side-title mb-30">
                                
                                <h2>About Besure Pest Control Melbourne </h2>
                            </div>
                            <div class="inner-about-content fix">
                            <p class="text-justify">By providing excellent pest control services to all customers and being honest and transparent, <b>Besure Pest Control Melbourne</b> has become the favourites of all the customers. Our core objective is to eliminate all types of pests from our client's place. We are involved in providing top-notch pest control services across Melbourne. With our hardworking staff, we thrive to provide reliable and affordable services. Backed with years of experience, skilled pest controllers and advanced technologies, we offer complete client satisfaction. We aim to find the root cause of pest infestation and work on eliminating those root causes. </p>
                            <p class="text-justify"><b>Besure Pest Control Melbourne</b> is a renowned company that provides sanitation, maintenance and pest control services in Melbourne's residential and business structures. Our services are easily reachable. We are dedicated to receive the calls anytime and provide hassle-free same day services after booking. Our staff is prompt and arrives at the place in time. We treasure our client's experience, trust and satisfaction. We thrive to provide quick and effective pest control services across all areas of Melbourne.  </p>    
                                <ul class="about-list"> 
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Same day pest control services.</li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> 24/7 availability </li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Emergency services  </li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Hassle-free booking system  </li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Free quotation over the phone call  </li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Reasonable and cost-effective services  </li>
                                    <li><span class="check-icon"><i class="fal fa-check"></i></span> Serve all areas of Melbourne  </li>
                                </ul> 
                            </div>
                        </div>
                        
                        
            
                    </div>
                </div>
            </section>
            
            <div class="container">                
                <input type="text" id="category_input" />
                <button id="rest-btn" onclick="fetchapi()">Fetch REST API </button>
            </div>
            <div class="container">                
                <div id="rest-div"></div>
            </div>
            <!-- about-area-end -->
         
        </div>
    </section>

    <!-- Testimonial Section Two -->
    <!-- <section class="testimonials-section-two padding">
        <div class="auto-container">
            <div class="sec-title text-center">
                <div class="sub-title">Testimonials</div>
                <h2>Customer Reviews</h2>
            </div>
            <?php echo do_shortcode('[reviews-carousel]'); ?>
             </div>
    </section> -->
     <!--Contact form section -->
<?php get_template_part( 'template-parts/footer', 'form' ); ?>
<style>
.contact-form-section{
    padding-top:20px!important;
}
@media only screen and (max-width: 575px){
.about-us-section .image-wrapper {
    padding-bottom: 0;
    margin: 0;
}}
</style>
 <?php get_footer(); ?>